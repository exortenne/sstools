rule DoomsdayLoader
{
    strings:
        $s1 = "net/java/aUT" ascii wide
        $s2 = "net/java/bUT" ascii wide
        $s3 = "net/java/cUT" ascii wide
        $s4 = "net/java/dUT" ascii wide
        $s5 = "net/java/eUT" ascii wide
        $s6 = "net/java/f.class" ascii wide
        $s7 = "net/java/g.class" ascii wide
        $s8 = "net/java/h.class" ascii wide
        $s9 = "net/java/i.class" ascii wide
        $s10 = "net/java/k.class" ascii wide
        $s11 = "net/java/l.class" ascii wide
        $s12 = "net/java/m.class" ascii wide
        $s13 = "net/java/r.class" ascii wide
        $s14 = "net/java/s.class" ascii wide
        $s15 = "net/java/t.class" ascii wide
        $s16 = "net/java/y.class" ascii wide
        $s17 = "DtQ.IOJ_" ascii wide
        $s18 = "JabxGW/" ascii wide
        $s19 = "RplImkD" ascii wide
        $s20 = "WJfqANb" ascii wide
        $s21 = "XWbn\\Dh" ascii wide
        $s22 = "sxXhB_cE" ascii wide
        $s23 = "DS4bVMK" ascii wide
        $s24 = "RMVaGG" ascii wide
        $s25 = "TIsJId" ascii wide
        $s26 = "UsqpeU" ascii wide
        $s27 = "VJI-N." ascii wide

    condition:
        13 of them
}

rule LeetClientLoader
{
    strings:
        $s1 = "Rh6C%o+{" ascii wide
        $s2 = "@5*Z5G" ascii wide
        $s3 = "x-Id@x?" ascii wide
        $s4 = "A\\MUALbJ" ascii wide
        $s5 = "UF8sI5" ascii wide
        $s6 = "JMo'wXT" ascii wide
        $s7 = "^T2EN3" ascii wide
        $s8 = "i!;1=g" ascii wide
        $s9 = "aKl0\"%" ascii wide
        $s10 = "G<$yZQ" ascii wide
        $s11 = "/_b^LM" ascii wide
        $s12 = "sdD*-z" ascii wide
        $s13 = "u(B\\GB" ascii wide
        $s14 = ">BFkrv" ascii wide
        $s15 = "I#<+>#" ascii wide
        $s16 = ";Ov;hm" ascii wide
        $s17 = "\\jgV4)" ascii wide
        $s18 = "\"Xi*/c" ascii wide
        $s19 = "Z$RtbfM:" ascii wide
        $s20 = "GoKkf{" ascii wide
        $s21 = "2l4+p*" ascii wide
        $s22 = "P!|Qj#" ascii wide
        $s23 = "%*^6&U" ascii wide
        $s24 = "Q Lcgb\"" ascii wide
        $s25 = "*O2&1}*" ascii wide
        $s26 = "#N<{jx'" ascii wide
        $s27 = "B)a{=N<{jl" ascii wide
        $s28 = "^y|!k)" ascii wide
        $s29 = "\"S4e &*" ascii wide
        $s30 = ")SHd^-" ascii wide
        $s31 = "N;]?zI" ascii wide
        $s32 = "ic)N.8R_ef" ascii wide
        $s33 = "AtC\"f," ascii wide
        $s34 = "Blq(]'&" ascii wide
        $s35 = "k8Mi_;!" ascii wide
        $s36 = "jq@uLk" ascii wide
        $s37 = "2M%3lWE" ascii wide
        $s38 = "x\\/AQH" ascii wide
        $s39 = "n;3k58" ascii wide
        $s40 = "YdaW=f" ascii wide
        $s41 = "q6@pqdv" ascii wide
        $s42 = "C}qh)y?)" ascii wide
        $s43 = "C5*qP    T" ascii wide
        $s44 = "=i9Cu1i" ascii wide
        $s45 = "V[5(>a?" ascii wide
        $s46 = "5Q[ih-" ascii wide
        $s47 = "!m`Y[H" ascii wide
        $s48 = "PoG$H%" ascii wide
        $s49 = "~-sR)h" ascii wide
        $s50 = "jHLB\\h" ascii wide
        $s51 = "#\"\"#/P" ascii wide
        $s52 = "/*<?35" ascii wide
        $s53 = "_%f\"/b" ascii wide
        $s54 = "Hy_R^9P" ascii wide
        $s55 = "J%7?#c" ascii wide
        $s56 = "j=78Rah" ascii wide
        $s57 = "^=Ajfr" ascii wide
        $s58 = "iiZdif" ascii wide
        $s59 = "0ykONk" ascii wide
        $s60 = "Wk;-%D!$" ascii wide
        $s61 = "J,1_\"'" ascii wide
        $s62 = "do\"\\dZX" ascii wide
        $s63 = "ucuo$j" ascii wide
        $s64 = "Sf lcaW" ascii wide
        $s65 = "g4#?`C" ascii wide
        $s66 = "a{P99x" ascii wide
        $s67 = "^}5523" ascii wide
        $s68 = "r1y6g7" ascii wide
        $s69 = "934F7t[" ascii wide
        $s70 = "s;}H/d" ascii wide
        $s71 = "^nO!%^" ascii wide
        $s72 = "/R:7QA" ascii wide
        $s73 = "zjJ({|" ascii wide
        $s74 = "f;S2AR" ascii wide
        $s75 = "I@E%Ir" ascii wide
        $s76 = "Ez9GQ -" ascii wide
        $s77 = "G^Liik" ascii wide
        $s78 = "dgXMRh" ascii wide

    condition:
        35 of them
}