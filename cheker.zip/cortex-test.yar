rule CortexPosible
{

    strings:
        $s1  = "0[^_A\\A]H" ascii wide
        $s2  = "8[^_]A\\A]" ascii wide
        $s3  = "@[^_A\\A]H" ascii wide
        $s4  = "ATUWVSH" ascii wide
        $s5  = "ATVSH" ascii wide
        $s6  = "AUATUWVSH" ascii wide
        $s7  = "AUATWVSH" ascii wide
        $s8  = "CloseHandle" ascii wide
        $s9  = "CreateThread" ascii wide
        $s10 = "GetProcAddress" ascii wide
        $s11 = "HcL$(H" ascii wide
        $s12 = "HcP<D" ascii wide
        $s13 = "KERNEL32.dll" ascii wide nocase
        $s14 = "LoadLibraryA" ascii wide
        $s15 = "P`p0" ascii wide
        $s16 = "dummy_relocation" ascii wide

    condition:
        10 of them
}