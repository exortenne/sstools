rule CortexLoaderNewDLL
{
    strings:
        $s1 = "P@zVfZo;'8\"6&B" ascii wide
        $s2 = "7(MV>v|\\?&<" ascii wide
        $s3 = "q\\,(yP&?}XSd" ascii wide
        $s4 = "[.l _~=b<S" ascii wide
        $s5 = "}<]%6X){xI5" ascii wide
        $s6 = "k<ER(k/k0\\/sY" ascii wide
        $s7 = "kk;~|:%]I*" ascii wide
        $s8 = "Q&Jv;*}*{d" ascii wide
        $s9 = "'%^&3.G(A" ascii wide
        $s10 = "'QOxnj,t_{`" ascii wide
        $s11 = "<jc! d&=7@" ascii wide
        $s12 = "e\"'o|1ld@+" ascii wide
        $s13 = "@[^_A\\A]H" ascii wide
        $s14 = ")L_j=?o,y" ascii wide
        $s15 = "7(ue!C|\\-" ascii wide
        $s16 = "8[^_]A\\A]" ascii wide
        $s17 = "\\V-]|^#a" ascii wide
        $s18 = "\\j8/Y{)O=" ascii wide
        $s19 = "0[^_A\\A]H" ascii wide
        $s20 = "$?Y|D[YkmY" ascii wide
        $s21 = "(_17Z}*sd" ascii wide
        $s22 = "QU(b`)=^" ascii wide
        $s23 = "V-d^w _]" ascii wide
        $s24 = "`@z{k=g^" ascii wide
        $s25 = "t |:*Qw!" ascii wide
        $s26 = "@|)1<|^" ascii wide
        $s27 = "yGHA\\MKYR G" ascii wide
        $s28 = "! |o=@y" ascii wide
        $s29 = "$d?:J&-" ascii wide
        $s30 = "&JV9H:[7@" ascii wide
        $s31 = "-#Ouej$^" ascii wide
        $s32 = "-)&7SzX5i" ascii wide
        $s33 = "4XK+$(P[" ascii wide
        $s34 = ":^(*5X)r" ascii wide
        $s35 = "W>kY?SB*r" ascii wide
        $s36 = "\\6B.\"k?t" ascii wide
        $s37 = "d%+9@`_" ascii wide
        $s38 = "j-]w>z.O" ascii wide
        $s39 = "n=vi0.i.sQ" ascii wide
        $s40 = "p a[^x|E" ascii wide
        $s41 = "sw>(6[g|" ascii wide
        $s42 = "|}#&JQ+" ascii wide
        $s43 = "#y$ $3>" ascii wide
        $s44 = "+,{^{tg" ascii wide
        $s45 = "-<}a6X-G" ascii wide
        $s46 = ".]}}\\sd" ascii wide
        $s47 = "s( .t^sa" ascii wide
        $s48 = "!D& em*" ascii wide
        $s49 = "\"Xkf.<7@" ascii wide
        $s50 = "%<5_6X," ascii wide
        $s51 = "%<>B5X-y" ascii wide
        $s52 = "&J~;US\"" ascii wide
        $s53 = "'`bq^1Yc" ascii wide
        $s54 = "($<^wr6" ascii wide
        $s55 = "+%|^;b" ascii wide
        $s56 = "+DR@dk.w" ascii wide
        $s57 = "+b?]G\"j" ascii wide
        $s58 = "-<.c6X}" ascii wide
        $s59 = ".&WJ!`g" ascii wide
        $s60 = ".U/b4yX#" ascii wide
        $s61 = "/W$ }~" ascii wide
        $s62 = "/[_I]&" ascii wide
        $s63 = "2d{~o:gV" ascii wide
        $s64 = "7$_|t;z" ascii wide
        $s65 = "7Xc<t_{b" ascii wide
        $s66 = ":P^96X-q" ascii wide
        $s67 = ":}|)-C" ascii wide
        $s68 = "<L*5X-@c" ascii wide
        $s69 = "<|j.}^" ascii wide
        $s70 = "=>A#@7Xk" ascii wide
        $s71 = "?$t_{`" ascii wide
        $s72 = "?y^#c O" ascii wide
        $s73 = "A-;0\"Q{" ascii wide
        $s74 = "A<=# |" ascii wide
        $s75 = "D<$]|\"" ascii wide
        $s76 = "F\\bH3 ^w" ascii wide
        $s77 = "Gg\" *{k" ascii wide
        $s78 = "MR!Nk {7" ascii wide
        $s79 = "Qp)TwO}qF" ascii wide
        $s80 = "SU%Z^3f#" ascii wide
        $s81 = "Y&[]mpPu" ascii wide
        $s82 = "Y. K<6@" ascii wide
        $s83 = "[H{s@iN4" ascii wide
        $s84 = "_E9^dHX<" ascii wide
        $s85 = "cx{np 9tr" ascii wide
        $s86 = "e<-$6X|" ascii wide
        $s87 = "j[y5-Av_" ascii wide
        $s88 = "jgCL#:P7@" ascii wide
        $s89 = "l`-BK{^" ascii wide
        $s90 = "o[u8h 2@" ascii wide
        $s91 = "q^R/3&jv" ascii wide
        $s92 = "y=/\\&@" ascii wide
        $s93 = "{/f'8_T" ascii wide
        $s94 = "}$TN?\"V" ascii wide
        $s95 = "(K|?(&" ascii wide
        $s96 = "-<^Q6X-" ascii wide
        $s97 = "6HMC .gHw" ascii wide
        $s98 = "7(x7?{ST" ascii wide
        $s99 = "<ub?:bce" ascii wide
        $s100 = "I=>T:T7@" ascii wide
        $s101 = "L$ 1L$ A" ascii wide
        $s102 = "L$(1L$(D" ascii wide
        $s103 = "g_+p_k`" ascii wide
        $s104 = "~Ky^#c#" ascii wide
        $s105 = "!&=/^" ascii wide
        $s106 = "!{*?<" ascii wide
        $s107 = "\"%w^sAJ" ascii wide
        $s108 = "\"lwns;(" ascii wide
        $s109 = "#'x^}p" ascii wide
        $s110 = "#=|XcaK" ascii wide
        $s111 = "#>A<6@" ascii wide
        $s112 = "$]&@+" ascii wide
        $s113 = "%<fa6X)" ascii wide
        $s114 = "%b>S\\(" ascii wide
        $s115 = "&JV6 ]H" ascii wide
        $s116 = "&dq =7@" ascii wide
        $s117 = "&f}i<7@" ascii wide
        $s118 = "'$t_{b" ascii wide
        $s119 = "(mc,nS*" ascii wide
        $s120 = ")6c={<" ascii wide
        $s121 = "*%$f=g" ascii wide
        $s122 = "*_Nb=-" ascii wide
        $s123 = "*|/6X=" ascii wide
        $s124 = "-<^[6X" ascii wide
        $s125 = "-<o{5X." ascii wide
        $s126 = "/(18{>" ascii wide
        $s127 = "/?:%)" ascii wide
        $s128 = "1%[y^kc" ascii wide
        $s129 = "1O|^=7@" ascii wide
        $s130 = "2a^\"4,A" ascii wide
        $s131 = "3(\\A'Nq" ascii wide
        $s132 = "3=B@#'" ascii wide
        $s133 = "4.c=}^" ascii wide
        $s134 = "4X-@,[" ascii wide
        $s135 = "4X-Zhj2&" ascii wide
        $s136 = "4Xf'G]Nb" ascii wide
        $s137 = "5zF1/c7LX" ascii wide
        $s138 = "6X-O+o!" ascii wide
        $s139 = "7&Jb'LST" ascii wide
        $s140 = "7&J~.0S" ascii wide
        $s141 = "7(al$#S" ascii wide
        $s142 = ";hDa|vJf" ascii wide
        $s143 = "<~U6X-m" ascii wide
        $s144 = "=!,_zB" ascii wide
        $s145 = "=-cY<7@" ascii wide
        $s146 = "=<4p5X-W" ascii wide
        $s147 = ">I,*\\3" ascii wide
        $s148 = ">o|d2!y" ascii wide
        $s149 = "@\"aneYXW" ascii wide
        $s150 = "AChb?]`" ascii wide
        $s151 = "B-I`(OG" ascii wide
        $s152 = "C IO_K{" ascii wide
        $s153 = "E'{\\#T" ascii wide
        $s154 = "E@}S|(" ascii wide
        $s155 = "I!@yXi&" ascii wide
        $s156 = "Jp^+`\"" ascii wide
        $s157 = "L #sO|x" ascii wide
        $s158 = "O,v~2\\s" ascii wide
        $s159 = "O\\\"R *" ascii wide
        $s160 = "Qp)TvO}p}" ascii wide
        $s161 = "Qp)TwO}q" ascii wide
        $s162 = "R~:(}X" ascii wide
        $s163 = "T\\ 3)HD" ascii wide
        $s164 = "VbB}u]hd" ascii wide
        $s165 = "[t!/I>" ascii wide
        $s166 = "^`}e~O" ascii wide
        $s167 = "_>7<L|" ascii wide
        $s168 = "_@T(:j" ascii wide
        $s169 = "_k+5?dr" ascii wide
        $s170 = "_qF:o,I" ascii wide
        $s171 = "_}!=>" ascii wide
        $s172 = "`!H2xL:" ascii wide
        $s173 = "b:}*{d" ascii wide
        $s174 = "c<|^;b" ascii wide
        $s175 = "cw@?<+" ascii wide
        $s176 = "cwO}hc2}X" ascii wide
        $s177 = "d]C[K%N" ascii wide
        $s178 = "dp]~O|o" ascii wide
        $s179 = "fj%}*sd" ascii wide
        $s180 = "g_X65]=" ascii wide

    condition:
        50 of them
}

rule CortexLoaderNewEXE
{
    strings:
        $s1 = "U@a4l" ascii wide
        $s2 = "|3GB(" ascii wide
        $s3 = "]Yb>!_" ascii wide
        $s4 = "6c?F%" ascii wide
        $s5 = "Z8N/c" ascii wide
        $s6 = "5\"[,I" ascii wide
        $s7 = "kMIK[qU-" ascii wide
        $s8 = "&Uwl2X" ascii wide
        $s9 = "6c'G%" ascii wide
        $s10 = "z[j0n" ascii wide
        $s11 = "Rj;gn" ascii wide
        $s12 = "Zj1dWz%" ascii wide
        $s13 = "M+wEL" ascii wide
        $s14 = "Rj;mZR" ascii wide
        $s15 = "B%i{VJ" ascii wide
        $s16 = ")`Rty]" ascii wide
        $s17 = "N^Nm{O" ascii wide
        $s18 = "^myRm" ascii wide
        $s19 = "j\\Ehw" ascii wide
        $s20 = "nZS{v" ascii wide
        $s21 = "&W|%y" ascii wide
        $s22 = "1)SB$" ascii wide
        $s23 = "[gnD%" ascii wide
        $s24 = "|37p'" ascii wide
        $s25 = "@^Bty@" ascii wide
        $s26 = "dXb\"7naOb" ascii wide
        $s27 = "2gq 7" ascii wide
        $s28 = "cua~A" ascii wide
        $s29 = "/:`6Z" ascii wide
        $s30 = "b~A^r" ascii wide
        $s31 = "tZ(?*" ascii wide
        $s32 = "S`s-+" ascii wide
        $s33 = ":<mVb" ascii wide
        $s34 = "Jc;b6" ascii wide
        $s35 = "b~pKEbb" ascii wide
        $s36 = "b~pH3P(" ascii wide
        $s37 = "7rG~.#g" ascii wide
        $s38 = "A8c=#[" ascii wide
        $s39 = "2~ANb" ascii wide
        $s40 = "W0(TW" ascii wide
        $s41 = "8e;bWy)=H" ascii wide
        $s42 = "oM0x{" ascii wide
        $s43 = "/D*vC" ascii wide
        $s44 = "[/~Sm3" ascii wide
        $s45 = "3j\\{#m" ascii wide
        $s46 = "1)SK%" ascii wide
        $s47 = "0L>k%" ascii wide
        $s48 = "FmHr|" ascii wide
        $s49 = "F% 6F" ascii wide
        $s50 = "/E*vF" ascii wide
        $s51 = "/A*vz" ascii wide
        $s52 = "FmJ?C" ascii wide
        $s53 = "/E*v>" ascii wide
        $s54 = "1)SR%" ascii wide
        $s55 = "QJS>z%" ascii wide
        $s56 = "RE:n^" ascii wide
        $s57 = "Rb+j^" ascii wide
        $s58 = "n)UF%" ascii wide
        $s59 = "`H6t`R" ascii wide
        $s60 = "9'(qF" ascii wide
        $s61 = "{[j4j" ascii wide
        $s62 = "j*5 K" ascii wide
        $s63 = "}?fj3Suj2@" ascii wide
        $s64 = "CjCU]\"" ascii wide
        $s65 = "/8uT:\"" ascii wide
        $s66 = "5[j4g" ascii wide
        $s67 = "KM]Dqr" ascii wide
        $s68 = "#gjZZ" ascii wide
        $s69 = "e<8kZ [" ascii wide
        $s70 = "N*vzE;" ascii wide
        $s71 = "5? `y" ascii wide
        $s72 = "Rb+nZJp" ascii wide
        $s73 = "r' RU" ascii wide
        $s74 = "Sc'g!" ascii wide
        $s75 = "&\\YdH" ascii wide
        $s76 = "_lQ8\\" ascii wide
        $s77 = "]YRu2" ascii wide
        $s78 = "Rj3n^*9J" ascii wide
        $s79 = "><wMqnNpC" ascii wide
        $s80 = "2[Ru:" ascii wide
        $s81 = "-[T6N" ascii wide
        $s82 = "'7 ds" ascii wide
        $s83 = "QTM27~" ascii wide
        $s84 = "7 ayU" ascii wide
        $s85 = "^;C:Wa" ascii wide
        $s86 = "T}2gb" ascii wide
        $s87 = "F2RF n" ascii wide
        $s88 = "8[b!b" ascii wide
        $s89 = "Rj:j\\" ascii wide
        $s90 = "QT}rC" ascii wide
        $s91 = "/@n\\B" ascii wide
        $s92 = "hnZ:r" ascii wide
        $s93 = "uF1b\\" ascii wide
        $s94 = "Ng,\\n" ascii wide
        $s95 = "e\\0_T" ascii wide
        $s96 = "D?nZZp" ascii wide
        $s97 = "f RvX" ascii wide
        $s98 = "mj[F8d]" ascii wide
        $s99 = "[RD9b" ascii wide
        $s100 = "\"[Ruz" ascii wide
        $s101 = "!I.sBd" ascii wide
        $s102 = "7CR*\\" ascii wide
        $s103 = "uj1g\\" ascii wide
        $s104 = "!RD1o" ascii wide
        $s105 = "9Ybmz[" ascii wide
        $s106 = "Rb!g)" ascii wide
        $s107 = ".0uT<dZ" ascii wide
        $s108 = "jZZH`" ascii wide
        $s109 = "Rj;)`" ascii wide
        $s110 = "[b)nZ" ascii wide
        $s111 = "Z.#Rc#)U" ascii wide
        $s112 = "R,e:@" ascii wide
        $s113 = "^Rk:j^" ascii wide
        $s114 = "(R-rF" ascii wide
        $s115 = ";Rb g" ascii wide
        $s116 = "^7jRe" ascii wide
        $s117 = "\"9)_#T" ascii wide
        $s118 = ".`*f{@NI" ascii wide
        $s119 = "RRc(n" ascii wide
        $s120 = ":ub$nZ" ascii wide
        $s121 = "m<<)0.[" ascii wide
        $s122 = "0$.$#nZ" ascii wide
        $s123 = "&W au" ascii wide
        $s124 = "+Rb*@" ascii wide
        $s125 = "8ub l\\" ascii wide
        $s126 = "9RF:)`" ascii wide
        $s127 = "mkRD;nN" ascii wide
        $s128 = "cp )~Z" ascii wide
        $s129 = "9 +],glh5" ascii wide
        $s130 = "sk)TF%" ascii wide
        $s131 = "6)]F%" ascii wide
        $s132 = "_x6+ ov" ascii wide
        $s133 = "V*T2%" ascii wide
        $s134 = "5)PF%" ascii wide
        $s135 = "#}<-qX" ascii wide
        $s136 = "B!TuT" ascii wide
        $s137 = "z%>F%" ascii wide
        $s138 = ")[beZ" ascii wide
        $s139 = "mE/mu" ascii wide
        $s140 = "SE6f!" ascii wide
        $s141 = "mjRT1$" ascii wide
        $s142 = "GA d) q" ascii wide
        $s143 = "9Zb+j" ascii wide
        $s144 = "1+STH" ascii wide
        $s145 = "}rWF%xP" ascii wide
        $s146 = "!yEi1" ascii wide
        $s147 = ".d\\R4" ascii wide
        $s148 = "d[F(o" ascii wide
        $s149 = "l2Vm{W" ascii wide
        $s150 = "31_<x1rN |" ascii wide
        $s151 = "g?P7L\"x" ascii wide
        $s152 = "o}jhuJ" ascii wide
        $s153 = "RG4>b" ascii wide
        $s154 = "f(T4R" ascii wide
        $s155 = "hM=)>" ascii wide
        $s156 = "C~YC y" ascii wide
        $s157 = "[pTK8Z" ascii wide
        $s158 = "b*mG6" ascii wide
        $s159 = "2WJ<Y" ascii wide
        $s160 = "<!cXJ" ascii wide
        $s161 = "h<6/<" ascii wide
        $s162 = "()g/VG" ascii wide
        $s163 = "/-tU6" ascii wide
        $s164 = "fd-,P" ascii wide
        $s165 = "ly~[Y" ascii wide
        $s166 = "0c#BI" ascii wide
        $s167 = "z+q`fB" ascii wide
        $s168 = "g1!(c" ascii wide
        $s169 = "9b Q.+" ascii wide
        $s170 = ".qvF%" ascii wide
        $s171 = "U*5qced|" ascii wide
        $s172 = "U`x (" ascii wide
        $s173 = "3ps N" ascii wide
        $s174 = "h.-T.cB}" ascii wide
        $s175 = "7>,#i%" ascii wide
        $s176 = "qZvF%" ascii wide
        $s177 = "j6t?p;" ascii wide
        $s178 = "kQSVY&" ascii wide
        $s179 = "nK\"l %" ascii wide
        $s180 = "TdYI*T`" ascii wide
        $s181 = "|txt`8" ascii wide
        $s182 = "$DWj}R" ascii wide
        $s183 = ".CY#e" ascii wide
        $s184 = "C{GY%h" ascii wide
        $s185 = "N3g84+" ascii wide
        $s186 = "BFdc?" ascii wide
        $s187 = ")F~=97" ascii wide
        $s188 = "Lk$ Z" ascii wide
        $s189 = "g>EV16" ascii wide
        $s190 = "mc-Z/oW" ascii wide
        $s191 = "'yFC!" ascii wide
        $s192 = "t=A_3" ascii wide
        $s193 = "y2mM*" ascii wide
        $s194 = "O0Te<bv" ascii wide
        $s195 = "/Ntn%l\\" ascii wide
        $s196 = "NQ)ug" ascii wide
        $s197 = "]Y@xEib]" ascii wide
        $s198 = "X-ykl`n" ascii wide
        $s199 = "j`Y8N" ascii wide
        $s200 = ",t3k_T" ascii wide

    condition:
        50 of them
}

rule CortexLoaderOldDLL
{
    strings:
        $s1  = "! iBxx6" ascii
        $s2  = "!#Z:iF" ascii
        $s3  = "!IxRH" ascii
        $s4  = "!g\\N{" ascii
        $s5  = "!hP^3$" ascii
        $s6  = "!q$0|" ascii
        $s7  = "!tA-X4" ascii
        $s8  = "!w6q@" ascii
        $s9  = "!~O{Lm" ascii
        $s10 = "\")NoqW" ascii
        $s11 = "\"9 Y,+" ascii
        $s12 = "\"Cb+T" ascii
        $s13 = "\"k~+6Y" ascii
        $s14 = "\"lp|o" ascii
        $s15 = "# ](Q" ascii
        $s16 = "# gBa" ascii
        $s17 = "##n\\0" ascii
        $s18 = "#4_ZRa" ascii
        $s19 = "#B=S &" ascii
        $s20 = "#RV+4" ascii
        $s21 = "#T ::W" ascii
        $s22 = "#YY$V" ascii
        $s23 = "#]c=S%1" ascii
        $s24 = "#dv,Sc'Bn" ascii
        $s25 = "#iDF!^lw" ascii
        $s26 = "#kipN" ascii
        $s27 = "#lgqc" ascii
        $s28 = "#v|%o" ascii
        $s29 = "#{22D" ascii
        $s30 = "$!t;J" ascii
        $s31 = "$*Zp}N" ascii
        $s32 = "$.4b_" ascii
        $s33 = "$@DgG" ascii
        $s34 = "$ExSk" ascii
        $s35 = "$Fpo7" ascii
        $s36 = "$Ilu+" ascii
        $s37 = "$KWC9" ascii
        $s38 = "$R*5$." ascii
        $s39 = "$UEo$" ascii
        $s40 = "$VPCvQp" ascii
        $s41 = "$VPT(/" ascii
        $s42 = "$VP^9" ascii
        $s43 = "$VQN]" ascii
        $s44 = "$VQ]Q" ascii
        $s45 = "$VS{C" ascii
        $s46 = "$VTFp" ascii
        $s47 = "$VUAo" ascii
        $s48 = "$VVv&>" ascii
        $s49 = "$VW_(" ascii
        $s50 = "$Vj7." ascii
        $s51 = "$W[*g" ascii
        $s52 = "$ZpyP" ascii
        $s53 = "$Z|,D|" ascii
        $s54 = "$_5/c" ascii
        $s55 = "$cwl(7" ascii
        $s56 = "$cwq^" ascii
        $s57 = "$gdJnYG" ascii
        $s58 = "$herP" ascii
        $s59 = "$p>#^$5" ascii
        $s60 = "${j>T" ascii
        $s61 = "$|a<&$" ascii
        $s62 = "%!f5f" ascii
        $s63 = "%$)?@" ascii
        $s64 = "%)1`r" ascii
        $s65 = "%-s?4" ascii
        $s66 = "%9_7." ascii
        $s67 = "%?%uqB" ascii
        $s68 = "%AKIU A0" ascii
        $s69 = "%KY_7" ascii
        $s70 = "%QR&ja" ascii
        $s71 = "%S\"t*" ascii
        $s72 = "%VQEc" ascii
        $s73 = "%VQWx" ascii
        $s74 = "%VQdw" ascii
        $s75 = "%VQk" ascii
        $s76 = "%VRL<" ascii
        $s77 = "%VVOf0" ascii
        $s78 = "%VVz" ascii
        $s79 = "%VW_)" ascii
        $s80 = "%VWe4" ascii
        $s81 = "%VWvw;1" ascii
        $s82 = "%VWz!" ascii
        $s83 = "%XH{(\"" ascii
        $s84 = "%ZZ&6" ascii
        $s85 = "%a?>3" ascii
        $s86 = "%w&VV@" ascii
        $s87 = "%x0eH" ascii
        $s88 = "&!\"dj" ascii
        $s89 = "&'/r_]" ascii
        $s90 = "&=R5<" ascii
        $s91 = "&GT>nr4" ascii
        $s92 = "&Me6x@0" ascii
        $s93 = "&US+]<;" ascii
        $s94 = "&VVql" ascii
        $s95 = "&]der" ascii
        $s96 = "&l\":?" ascii
        $s97 = "&vsWO" ascii
        $s98 = "''[jwv" ascii
        $s99 = "'(6L" ascii
        $s100 = "'03AF" ascii

    condition:
        30 of them
}

rule CortexLoaderOldEXE
{
    strings:
        $s1 = "0[^_A\\A]H" ascii
        $s2 = "8[^_]A\\A]" ascii
        $s3 = "@[^_A\\A]H" ascii
        $s4 = "Y#td^~nm" ascii
        $s5 = "2,f ]8hEt" ascii
        $s6 = "10s>L03T" ascii
        $s7 = "V9U p46do" ascii
        $s8 = "Y7`prznQ" ascii
        $s9 = "S#?h|V!/^" ascii
        $s10 = ">e8G!G8," ascii
        $s11 = "t:Q\\nF=v" ascii
        $s12 = "_NO%fY=n" ascii
        $s13 = ".'{QD Bf" ascii
        $s14 = ",;y -pq!" ascii
        $s15 = "mV3VX,5M" ascii
        $s16 = "Dzb1qm CZ>~" ascii
        $s17 = "[&b`7(;{X" ascii
        $s18 = "?%UvFDjQ" ascii
        $s19 = "FY3FTnJn" ascii
        $s20 = "8yP;1X2Mg" ascii
        $s21 = "9?eanN@G8[l" ascii
        $s22 = "4G;F~>V1" ascii
        $s23 = "3/eQ/P[O" ascii
        $s24 = "Rp8y*b52" ascii
        $s25 = "1w_\"`23@" ascii
        $s26 = "woI>@VA(" ascii
        $s27 = ",)W'LZH," ascii
        $s28 = "L^p.Zk`r" ascii
        $s29 = ":?Zp`i/o" ascii
        $s30 = ":?Zp`i/wU" ascii
        $s31 = ":?Zp`i/gS" ascii
        $s32 = "(Ar<=`i/" ascii
        $s33 = ":?Zp`i/_>" ascii
        $s34 = ":?Zp`i/_<" ascii
        $s35 = ":?Zp`i/'\"" ascii
        $s36 = "NIKQ?s#KR" ascii
        $s37 = "Ypt5$F/Ev" ascii
        $s38 = "ur5wY}mRhM[" ascii
        $s39 = "dDd,.]cd9" ascii
        $s40 = "\\ <z.#lba@,oM" ascii
        $s41 = "j<z.SBZa@," ascii
        $s42 = "n\\<?VN%af" ascii
        $s43 = "ZEL v-o[" ascii
        $s44 = "J H@R[hX" ascii
        $s45 = "<6|93{_8h" ascii
        $s46 = "Ev_K ^8hMt,I" ascii
        $s47 = "^i?H-Av$" ascii
        $s48 = "lKg^8hAt*" ascii
        $s49 = "|#OhKg_8hE" ascii
        $s50 = "QJhX8h@t" ascii
        $s51 = "iJ(Y8hAr" ascii
        $s52 = "?f']_8hAr" ascii
        $s53 = "?f'[_8hAt" ascii
        $s54 = "iJ8>8hAr" ascii
        $s55 = "Jx:8hAtj" ascii
        $s56 = "f'#_8hAr" ascii
        $s57 = "Jx 8hAt," ascii
        $s58 = "f'?^8hMt%" ascii
        $s59 = "Ba|.%/vb" ascii
        $s60 = "27f'dX8h" ascii
        $s61 = "Jh>9hHt$" ascii
        $s62 = "f'(_8hAt" ascii
        $s63 = "29f'=_8hH8m" ascii
        $s64 = "f'u_8hHt" ascii
        $s65 = "(J8!8hEt-" ascii
        $s66 = "?f&C_8hAt" ascii
        $s67 = "?f'b\\8hAt-" ascii
        $s68 = "f-$^8hH|" ascii
        $s69 = "S0BW}P%)" ascii
        $s70 = "Pj8v:-!/" ascii
        $s71 = "JP]8hAt5" ascii
        $s72 = "J0f:hArT" ascii
        $s73 = "iK _8hMt-" ascii
        $s74 = "f'!_8hArdR" ascii
        $s75 = "JpU8hAt=" ascii
        $s76 = "?f*{]8hA" ascii
        $s77 = "0!+&oLiAv" ascii
        $s78 = "?f&v_8h@t$" ascii
        $s79 = "LNAt`]Frs" ascii
        $s80 = "?f'I\\8hDt" ascii
        $s81 = "J0R;hAtl" ascii
        $s82 = "J@L;hAt$" ascii
        $s83 = "^8hAr|.l" ascii
        $s84 = "?f&A_8hEt*" ascii
        $s85 = "aJPZ8hAt" ascii
        $s86 = "yJ@'8hEv" ascii
        $s87 = "f'pt:hHt" ascii
        $s88 = "JHQ8hAv*" ascii
        $s89 = "kKv^8h0L" ascii
        $s90 = "^8h:?%)/" ascii
        $s91 = "f' ^8hAt" ascii
        $s92 = "f'h_8hAz" ascii
        $s93 = "iK8c3hAr" ascii
        $s94 = "n)^hH\\GOA*&N" ascii
        $s95 = "z~bw F1&" ascii
        $s96 = "BEJ^9\"k(" ascii
        $s97 = "#vZ?-AuO@" ascii
        $s98 = "r{TN48JV" ascii
        $s99 = "S%j[qjH\\" ascii
        $s100 = ":{TJ3. z" ascii
        $s101 = "<'zu$4X\\<" ascii
        $s102 = "veE{\\K]ML" ascii
        $s103 = "B. v {\\{\\" ascii
        $s104 = "C. v {\\p\\" ascii
        $s105 = "C. v {\\s]" ascii
        $s106 = "j{RC`caf" ascii
        $s107 = "\\[]eYi5\\" ascii
        $s108 = "4!>3RJ`u" ascii
        $s109 = "C. v s]s" ascii
        $s110 = "z{TN49`&A3" ascii
        $s111 = "4I>3RJav" ascii
        $s112 = "$I>3RJ`H" ascii
        $s113 = "o{Z&0&re" ascii
        $s114 = "{TN49J\";3" ascii
        $s115 = "Q6z\\_]eM" ascii
        $s116 = ">vRn`Caf" ascii
        $s117 = "C. v v\\k]" ascii
        $s118 = ",j93RJ`Gv_r" ascii
        $s119 = "z{TN49J*;" ascii
        $s120 = "r{TN$9JV" ascii
        $s121 = ":{RJ`eye2" ascii
        $s122 = "i{Tf4U@r" ascii
        $s123 = "{TN49J\"Y@" ascii
        $s124 = "C. vj{\\s" ascii
        $s125 = "{TrTi 9:3" ascii
        $s126 = ">3RJan`r" ascii
        $s127 = ". Z8vRJa" ascii
        $s128 = "B<. [8{Ts" ascii
        $s129 = "*;{TN49J" ascii
        $s130 = "{TJ$' d?A<" ascii
        $s131 = ":{RJ`eye:{\\" ascii
        $s132 = "*{RX`eye8{T" ascii
        $s133 = ". p;F2a\"" ascii
        $s134 = "Tk+.Hr<{Z" ascii
        $s135 = "{RX`savF0" ascii
        $s136 = "C. vz{\\P\\" ascii
        $s137 = ">3RJmc T" ascii
        $s138 = "{TK4/vSO" ascii
        $s139 = "{TN4;JVzf" ascii
        $s140 = "A. v {\\`\\" ascii
        $s141 = "_cN.HZ>{" ascii
        $s142 = ":{m2NWVI|u" ascii
        $s143 = "WToH`sS3" ascii
        $s144 = "Ia: #YW~" ascii
        $s145 = ":{o{ZOnM" ascii
        $s146 = ":'aQ}c9f" ascii
        $s147 = "nK(&dIYW~" ascii
        $s148 = "+nCO<s:3" ascii
        $s149 = "F^I!jt@\"" ascii
        $s150 = ":{mnZV$3" ascii
        $s151 = ":{m50}39" ascii
        $s152 = ":{oA|}ag" ascii
        $s153 = ".3Z4fV0'" ascii
        $s154 = ":{m6Xd\"%" ascii
        $s155 = "/ r\"~^KU=" ascii
        $s156 = "\\/ qr~^RL'" ascii
        $s157 = ". p2z^ZU=" ascii
        $s158 = "\\/ qr~^PL'" ascii
        $s159 = "T. pz{^ZU>" ascii
        $s160 = "d. pJ{^]U?" ascii
        $s161 = "d. sJ{^BU?" ascii
        $s162 = "I_^K{ Z\\" ascii
        $s163 = "T. sz{^BU>" ascii
        $s164 = "$. s {^BU=" ascii
        $s165 = "IAzl5C86" ascii
        $s166 = "|/ rR~^KN'" ascii
        $s167 = "d. sJ{^@U<" ascii
        $s168 = "t. pZ{^[U?" ascii
        $s169 = "\"-Mq+.hw" ascii
        $s170 = "A/JN'm|s" ascii
        $s171 = "/y4,M=\"x" ascii
        $s172 = "-i=-Mu] >" ascii
        $s173 = "6 -My)N8" ascii
        $s174 = "AAY 2oA." ascii
        $s175 = "0gy!&^2)" ascii
        $s176 = ">[y1 5\"<" ascii
        $s177 = "k:2Rw3dL" ascii
        $s178 = "?`*8S?tzo" ascii
        $s179 = "1C TT {<" ascii
        $s180 = "AEr9XclRw" ascii

    condition:
        60 of them
}